﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class returnbooks : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=LENOVO-PC\SQLEXPRESS;Initial Catalog=dblibrary;Integrated Security=True");
        public returnbooks()
        {
            InitializeComponent();
        }

        private void returnbooks_Load(object sender, EventArgs e)
        {
            if(con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
        }
        public void fillgrid(string studid)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from issuebooks where studid ='" + studid.ToString() + "' and books_return_date=''";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            fillgrid(textBox1.Text);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            panel3.Visible = true;
            int i;
            i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from issuebooks where Id ='" + i + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                lblbooksname.Text = dr["books_name"].ToString();
                lblissuedate.Text = dr["books_issue_date"].ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update issuebooks set books_return_date='" + dateTimePicker1.Value.ToString() + "' where Id ='" + i + "'";
            cmd.ExecuteNonQuery();

            SqlCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "update tblbooks set available_qty=available_qty+1 where books_name='" + lblbooksname.Text + "'";
            cmd1.ExecuteNonQuery();


            MessageBox.Show("Books Returned Successfully!");

            panel3.Visible = true;

            fillgrid(textBox1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            viewbooks vb = new viewbooks();
            vb.Show();
        }
    }
}
