﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class viewbooks : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=LENOVO-PC\SQLEXPRESS;Initial Catalog=dblibrary;Integrated Security=True");
        public viewbooks()
        {
            InitializeComponent();
        }
        private void viewbooks_Load(object sender, EventArgs e)
        {

            disp_books();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = 0;
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from tblbooks where books_name like ('%" + textBox1.Text + "%')";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                i = Convert.ToInt32(dt.Rows.Count.ToString());

                dataGridView1.DataSource = dt;
                con.Close();

                if (i == 0)
                {
                    MessageBox.Show("Sorry! No books found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from tblbooks where books_name like ('%" + textBox1.Text + "%')";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            panel2.Visible = true;
            int i;
            i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from tblbooks where id=" + i + "";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);

                foreach (DataRow dr in dt.Rows)
                {
                    name.Text = dr["books_name"].ToString();
                    author.Text = dr["books_author"].ToString();
                    publication.Text = dr["books_publication"].ToString();
                    dateTimePicker1.Value = Convert.ToDateTime(dr["books_date"].ToString());
                    price.Text = dr["books_price"].ToString();
                    quantity.Text = dr["books_quantity"].ToString();
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(dataGridView1.SelectedCells[0].Value.ToString());
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update tblbooks set books_name='" + name.Text + "', books_author='" + author.Text + "', books_publication='" + publication.Text + "', books_date='" + dateTimePicker1.Value + "', books_price='" + price.Text + "', books_quantity='" + quantity.Text + "' where id=" + i + "";
                cmd.ExecuteNonQuery();
                con.Close();
                disp_books();
                MessageBox.Show("Records Updated Successfully!");
                panel2.Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            addbooks ab = new addbooks();
            ab.Show();

        }
        private void button4_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow row in dataGridView1.Rows)
            {
                object rows = row.Cells["cell_del"].Value;
                if(rows == "yes")
                {
                    if(MessageBox.Show("Delete this book?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        dblibraryDataSet.tblbooks.Rows[row.Index].Delete();
                        tblbooksTableAdapter.Update(dblibraryDataSet.tblbooks);
                        disp_books();
                    }
                }
            }
        }
        public void disp_books()
        {       
            try
            {
                
                con.Open();
                this.tblbooksTableAdapter.Fill(this.dblibraryDataSet.tblbooks);
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from tblbooks";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void viewbooks_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dblibraryDataSet2.tblbooks' table. You can move, or remove it, as needed.
            this.tblbooksTableAdapter1.Fill(this.dblibraryDataSet2.tblbooks);
            // TODO: This line of code loads data into the 'dblibraryDataSet.tblbooks' table. You can move, or remove it, as needed.
            this.tblbooksTableAdapter.Fill(this.dblibraryDataSet.tblbooks);
            // TODO: This line of code loads data into the 'dblibraryDataSet.tblbooks' table. You can move, or remove it, as needed.

        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            viewstu vs = new viewstu();
            vs.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            addstu ads = new addstu();
            ads.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            issuebook ib = new issuebook();
            ib.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            returnbooks rb = new returnbooks();
            rb.Show();
        }
    }
}
