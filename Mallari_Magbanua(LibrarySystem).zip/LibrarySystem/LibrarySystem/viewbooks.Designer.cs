﻿namespace LibrarySystem
{
    partial class viewbooks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button2 = new System.Windows.Forms.Button();
            this.quantity = new System.Windows.Forms.TextBox();
            this.price = new System.Windows.Forms.TextBox();
            this.publication = new System.Windows.Forms.TextBox();
            this.author = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tblbooksBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dblibraryDataSet = new LibrarySystem.dblibraryDataSet();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.tblbooksTableAdapter = new LibrarySystem.dblibraryDataSetTableAdapters.tblbooksTableAdapter();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.dblibraryDataSet2 = new LibrarySystem.dblibraryDataSet2();
            this.tblbooksBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tblbooksTableAdapter1 = new LibrarySystem.dblibraryDataSet2TableAdapters.tblbooksTableAdapter();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booksnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booksauthorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookspublicationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booksdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookspriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booksquantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.available_qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cell_del = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblbooksBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dblibraryDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dblibraryDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblbooksBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(493, 20);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(155, 26);
            this.dateTimePicker1.TabIndex = 13;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(329, 158);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 34);
            this.button2.TabIndex = 12;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // quantity
            // 
            this.quantity.Location = new System.Drawing.Point(492, 114);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(156, 26);
            this.quantity.TabIndex = 11;
            // 
            // price
            // 
            this.price.Location = new System.Drawing.Point(492, 65);
            this.price.Name = "price";
            this.price.Size = new System.Drawing.Size(156, 26);
            this.price.TabIndex = 10;
            // 
            // publication
            // 
            this.publication.Location = new System.Drawing.Point(163, 114);
            this.publication.Name = "publication";
            this.publication.Size = new System.Drawing.Size(156, 26);
            this.publication.TabIndex = 8;
            // 
            // author
            // 
            this.author.Location = new System.Drawing.Point(163, 65);
            this.author.Name = "author";
            this.author.Size = new System.Drawing.Size(156, 26);
            this.author.TabIndex = 7;
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(163, 20);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(156, 26);
            this.name.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(418, 117);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Quantity";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(442, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(361, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Publication Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Publication Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(59, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Book Author";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(65, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Book Name";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Location = new System.Drawing.Point(41, 93);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(77, 31);
            this.button1.TabIndex = 2;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(7, 52);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(144, 21);
            this.textBox1.TabIndex = 1;
            this.textBox1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Book Name";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dateTimePicker1);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.quantity);
            this.panel2.Controls.Add(this.price);
            this.panel2.Controls.Add(this.publication);
            this.panel2.Controls.Add(this.author);
            this.panel2.Controls.Add(this.name);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(182, 365);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(725, 205);
            this.panel2.TabIndex = 5;
            this.panel2.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 39);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(160, 170);
            this.panel1.TabIndex = 4;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.booksnameDataGridViewTextBoxColumn,
            this.booksauthorDataGridViewTextBoxColumn,
            this.bookspublicationDataGridViewTextBoxColumn,
            this.booksdateDataGridViewTextBoxColumn,
            this.bookspriceDataGridViewTextBoxColumn,
            this.booksquantityDataGridViewTextBoxColumn,
            this.available_qty,
            this.cell_del});
            this.dataGridView1.DataSource = this.tblbooksBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(167, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(948, 298);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // tblbooksBindingSource
            // 
            this.tblbooksBindingSource.DataMember = "tblbooks";
            this.tblbooksBindingSource.DataSource = this.dblibraryDataSet;
            // 
            // dblibraryDataSet
            // 
            this.dblibraryDataSet.DataSetName = "dblibraryDataSet";
            this.dblibraryDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(167, 307);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 34);
            this.button3.TabIndex = 14;
            this.button3.Text = "Add Books";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(326, 307);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(108, 34);
            this.button4.TabIndex = 15;
            this.button4.Text = "Delete Books";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // tblbooksTableAdapter
            // 
            this.tblbooksTableAdapter.ClearBeforeFill = true;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(511, 307);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(118, 34);
            this.button5.TabIndex = 16;
            this.button5.Text = "Add Students";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(858, 307);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(98, 34);
            this.button6.TabIndex = 17;
            this.button6.Text = "Issue Books";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(1002, 307);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(113, 34);
            this.button7.TabIndex = 18;
            this.button7.Text = "Return Books";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(686, 307);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(113, 34);
            this.button8.TabIndex = 19;
            this.button8.Text = "View Students";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // dblibraryDataSet2
            // 
            this.dblibraryDataSet2.DataSetName = "dblibraryDataSet2";
            this.dblibraryDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblbooksBindingSource1
            // 
            this.tblbooksBindingSource1.DataMember = "tblbooks";
            this.tblbooksBindingSource1.DataSource = this.dblibraryDataSet2;
            // 
            // tblbooksTableAdapter1
            // 
            this.tblbooksTableAdapter1.ClearBeforeFill = true;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "No.";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // booksnameDataGridViewTextBoxColumn
            // 
            this.booksnameDataGridViewTextBoxColumn.DataPropertyName = "books_name";
            this.booksnameDataGridViewTextBoxColumn.HeaderText = "Book Name";
            this.booksnameDataGridViewTextBoxColumn.Name = "booksnameDataGridViewTextBoxColumn";
            this.booksnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // booksauthorDataGridViewTextBoxColumn
            // 
            this.booksauthorDataGridViewTextBoxColumn.DataPropertyName = "books_author";
            this.booksauthorDataGridViewTextBoxColumn.HeaderText = "Author";
            this.booksauthorDataGridViewTextBoxColumn.Name = "booksauthorDataGridViewTextBoxColumn";
            this.booksauthorDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bookspublicationDataGridViewTextBoxColumn
            // 
            this.bookspublicationDataGridViewTextBoxColumn.DataPropertyName = "books_publication";
            this.bookspublicationDataGridViewTextBoxColumn.HeaderText = "Publication Name";
            this.bookspublicationDataGridViewTextBoxColumn.Name = "bookspublicationDataGridViewTextBoxColumn";
            this.bookspublicationDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // booksdateDataGridViewTextBoxColumn
            // 
            this.booksdateDataGridViewTextBoxColumn.DataPropertyName = "books_date";
            this.booksdateDataGridViewTextBoxColumn.HeaderText = "Published Date";
            this.booksdateDataGridViewTextBoxColumn.Name = "booksdateDataGridViewTextBoxColumn";
            this.booksdateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bookspriceDataGridViewTextBoxColumn
            // 
            this.bookspriceDataGridViewTextBoxColumn.DataPropertyName = "books_price";
            this.bookspriceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.bookspriceDataGridViewTextBoxColumn.Name = "bookspriceDataGridViewTextBoxColumn";
            this.bookspriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // booksquantityDataGridViewTextBoxColumn
            // 
            this.booksquantityDataGridViewTextBoxColumn.DataPropertyName = "books_quantity";
            this.booksquantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.booksquantityDataGridViewTextBoxColumn.Name = "booksquantityDataGridViewTextBoxColumn";
            this.booksquantityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // available_qty
            // 
            this.available_qty.DataPropertyName = "available_qty";
            this.available_qty.HeaderText = "Available Quantity";
            this.available_qty.Name = "available_qty";
            // 
            // cell_del
            // 
            this.cell_del.HeaderText = "         Delete";
            this.cell_del.Name = "cell_del";
            this.cell_del.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cell_del.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.cell_del.TrueValue = "yes";
            // 
            // viewbooks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1150, 601);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "viewbooks";
            this.Text = "List of Books";
            this.Load += new System.EventHandler(this.viewbooks_Load_1);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblbooksBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dblibraryDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dblibraryDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblbooksBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox quantity;
        private System.Windows.Forms.TextBox price;
        private System.Windows.Forms.TextBox publication;
        private System.Windows.Forms.TextBox author;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private dblibraryDataSet dblibraryDataSet;
        private System.Windows.Forms.BindingSource tblbooksBindingSource;
        private dblibraryDataSetTableAdapters.tblbooksTableAdapter tblbooksTableAdapter;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private dblibraryDataSet2 dblibraryDataSet2;
        private System.Windows.Forms.BindingSource tblbooksBindingSource1;
        private dblibraryDataSet2TableAdapters.tblbooksTableAdapter tblbooksTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn booksnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn booksauthorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookspublicationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn booksdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookspriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn booksquantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn available_qty;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cell_del;
    }
}